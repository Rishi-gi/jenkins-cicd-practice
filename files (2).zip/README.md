# Jenkins CI/CD Practice – Journey Checker

A self-directed practice project for learning Git-based workflows, Jenkins pipelines,
Linux shell scripting and Python testing. The application itself is intentionally small
so the focus stays on the **pipeline**: how code gets built, tested and deployed
automatically every time a change is pushed.

## What the app does

`journey_checker` reads a CSV of transport journey records and flags data-quality issues:

| Status | Meaning |
|---|---|
| `NOT_TRACKED` | No GPS pings recorded |
| `PARTIAL` | Fewer than 80% of expected pings recorded |
| `MISSING_FIELD` | A required field is empty |
| `OK` | Record looks complete |

```bash
PYTHONPATH=src python3 -m journey_checker.cli data/sample_journeys.csv
```

## Pipeline

```
 git push ──► Jenkins ──► Checkout ──► Build ──► Test ──► Deploy
                                        │         │         │
                                  venv + flake8  pytest   package → release folder
                                                 + smoke   → "current" symlink
                                                   test    → post-deploy check
```

| Stage | Script | What it does |
|---|---|---|
| Checkout | (Jenkins) | Pulls the latest commit from GitHub |
| Build | `scripts/build.sh` | Fresh virtual environment, installs dependencies, lints with flake8 |
| Test | `scripts/test.sh` | Runs pytest (JUnit report shown in Jenkins) and a CLI smoke test |
| Deploy | `scripts/deploy.sh` | Packages a versioned tarball, releases it to a local folder, switches the `current` symlink, runs a post-deploy check |

`scripts/rollback.sh` points `current` back at the previous release.

Every script uses `set -euo pipefail`, so any failing command stops the pipeline at that stage.

## Project structure

```
├── Jenkinsfile               # declarative pipeline definition
├── jenkins/                  # Dockerfile + compose file to run Jenkins locally
├── scripts/                  # build / test / deploy / rollback shell scripts
├── src/journey_checker/      # the Python app
├── tests/                    # pytest unit tests
├── data/sample_journeys.csv  # sample input
└── docs/
    ├── SETUP.md              # how to run Jenkins and connect this repo
    ├── EXERCISES.md          # deliberate failures to practise troubleshooting
    └── TROUBLESHOOTING.md    # my log of pipeline failures and fixes
```

## Run locally without Jenkins

```bash
./scripts/build.sh
./scripts/test.sh
./scripts/deploy.sh
```

## What I practised

- Feature-branch workflow in Git (branch → commit → pull request → merge)
- Writing a declarative `Jenkinsfile` with stages and post-build actions
- Bash scripting for repeatable build, test and deploy steps
- Unit testing with pytest and publishing test reports in Jenkins
- Diagnosing failed builds from console output and documenting fixes (see `docs/TROUBLESHOOTING.md`)

## Limitations / next steps

- Deployment is to a local folder, not a real server or cloud environment
- Possible extensions: GitHub webhook trigger, multibranch pipeline (deploy only from `main`),
  Docker image build stage, GitHub Actions version of the same pipeline for comparison
